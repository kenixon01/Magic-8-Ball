package com.zybooks.magic8ball;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.AssetFileDescriptor;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.os.Vibrator;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Random;
import java.util.Scanner;

public class MainActivity extends AppCompatActivity implements SensorEventListener
    {

    float[] gravity = new float[3];
    private static final String TAG = "OMNI";
    private static final float VERTICAL_TOL = 0.3f;

    private final String APP_STATE = "It is certain.";

    private SensorManager manager;
    private long lastUpdate;
    private MediaPlayer popPlayer;
    private MediaPlayer backgroundPlayer;
    private TextToSpeech tts;

    private boolean isDown = false;
    private boolean isUp = false;

    private ArrayList<String> responselist;
    private TextView tvResponse;


    private CameraManager camManager;
    private String cameraId;

    private SharedPreferences prefs;
    private SharedPreferences.Editor editor;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences("shared", Context.MODE_PRIVATE);
        editor = prefs.edit();

        tvResponse=findViewById(R.id.tvResponse);
        getSupportActionBar().hide();
        if (savedInstanceState != null) {
            String appState = savedInstanceState.getString(APP_STATE);
            tvResponse.setText(appState);
        }



        manager = (SensorManager) getSystemService(SENSOR_SERVICE);
        lastUpdate = System.currentTimeMillis();
        popPlayer = new MediaPlayer();
        try {
            AssetFileDescriptor afd = getAssets().openFd("pop.ogg");
            popPlayer.setDataSource(afd.getFileDescriptor(),afd.getStartOffset(),afd.getLength());
            popPlayer.prepare();
            afd.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        responselist=new ArrayList<>();
        readFile();
        backgroundPlayer = MediaPlayer.create(this, R.raw.lightwaves);



        tts = new TextToSpeech(this, status -> {
            tts.setLanguage(Locale.US);
            tts.setSpeechRate(1.0f);

        });
    }
    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString(APP_STATE, tvResponse.getText().toString());
    }
    @Override
    protected void onResume() {
        super.onResume();
        tvResponse.setText(prefs.getString("msg", tvResponse.getText().toString()));
        manager.registerListener(this, manager.getDefaultSensor(Sensor.TYPE_GRAVITY),
                SensorManager.SENSOR_DELAY_UI);
        backgroundPlayer.start();

    }

    @Override
    protected void onPause() {
        super.onPause();
        editor.putString("msg", tvResponse.getText().toString());
        editor.apply();
        manager.unregisterListener(this);
        backgroundPlayer.pause();
    }

    @Override
    public void onSensorChanged(SensorEvent event) {

        //For gravity sensor, no need for low pass
        gravity[0] = event.values[0];
        gravity[1] = event.values[1];
        gravity[2] = event.values[2];

        long actualTime = System.currentTimeMillis();

        if (actualTime - lastUpdate > 100) {

            Log.i(TAG, "gravity[]=" + gravity[0] + ' ' + gravity[1] + ' ' + gravity[2]);


            if (inRange(gravity[2], -9.81f, VERTICAL_TOL)) {

                Log.i(TAG, "Down");

                if (!isDown) {
                    backgroundPlayer.pause();
                    popPlayer.start();

                    StringBuilder str=new StringBuilder();
                    for(int i=0;i<1000;i++){
                        str.append('O');
                    }
                    tts.speak("abracadabra", TextToSpeech.QUEUE_FLUSH, null, null);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        camManager=(CameraManager) getSystemService(Context.CAMERA_SERVICE);
                        //String
                        cameraId = null;
                        try {

                            for(int i=0;i<3;i++) {
                                cameraId = camManager.getCameraIdList()[0];
                                camManager.setTorchMode(cameraId, true);   //Turn ON
                                camManager.setTorchMode(cameraId, false);

                                try {
                                    Thread.sleep(500);
                                } catch (InterruptedException e) {
                                    e.printStackTrace();
                                }
                            }
                        } catch (CameraAccessException e) {
                            e.printStackTrace();
                        }
                    }
                    Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        long[] pattern = {0, 1000, 1000, 1000, 1000};
                        v.vibrate(pattern, -1);
                    } else {
                        //deprecated in API 26
                        v.vibrate(2000);
                    }
                    
                    backgroundPlayer.setVolume(1.0f, 1.0f);
                    backgroundPlayer.start();
                    isDown = true;
                    isUp = false;
                }

            } else if (inRange(gravity[2], 9.81f, VERTICAL_TOL)) {
                Log.i(TAG, "Up");
                if (!isUp) {
                    backgroundPlayer.setVolume(0.1f, 0.1f);
                    Random rand=new Random();
                    String responseString=responselist.get(rand.nextInt(20));
                    tvResponse.setText(responseString);
                    tts.speak(responseString, TextToSpeech.QUEUE_FLUSH, null, null);

                    backgroundPlayer.setVolume(1.0f, 1.0f);
                    isUp = true;
                    isDown = false;
                }

            } else {
                Log.i(TAG, "In between");
            }
            lastUpdate = actualTime;
        }

    }

    private boolean inRange(float value, float target,  float tol) {
        return value >= target-tol && value <= target+tol;
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
    void readFile() {
        try {
            InputStream is = this.getApplicationContext().getAssets().open("responses.txt");
            //InputStream is = getActivity().getAssets().open("tacomenu");
            Scanner scan = new Scanner(is);
            //ArrayList<String> list = new ArrayList<>();
            while (scan.hasNext()) {
                String line = scan.nextLine();

                responselist.add(line);
            }
            scan.close();

            is.close();

            System.out.println("From Read File : "+responselist);

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public void fabClick(View view) {

        Intent intent = new Intent(MainActivity.this,about.class);
        startActivity(intent);

    }


}
